package tests;

import org.testng.annotations.Test;

import pages.HomePage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Testfirst

{
	
	
	WebDriver d=new ChromeDriver();
	
	
	
	@Test
	public void test1() throws InterruptedException
	{
		
		HomePage homeobj=new HomePage(d);
        
		
		homeobj.clickonMake();
		
		homeobj.dragyearSliderright();
		
		homeobj.clickonModel();
		
		homeobj.clickonPrice();
		
		homeobj.clickonSearch();
		
	   String cars=  homeobj.getthecarstext();
	   
	   
	   System.out.println("The number of cars "+cars);
	   
		
		
		
		
		
		
	}
	

}
