package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ById;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Coordinates;
import org.openqa.selenium.interactions.Locatable;

import java.time.Duration;
import java.util.concurrent.TimeUnit;
import java.util.List;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.interactions.Action;

public class HomePage 
{
	
	
	double i=0.1;
	
	
	
	WebDriver d=new ChromeDriver();
	
	
	
	@FindBy(xpath="//div[@id=\"find-car\"]")
	WebElement findusersection;
	
	
	
	@FindBy(xpath="//select[@id=\"select_maker_cd\"]")
	WebElement wmake;
	
	

	@FindBy(xpath="(//div[@class=\"wcm\"]//span)[1]")
	WebElement noofcars;
	
	
	
	
	@FindBy(xpath="//span[@id=\"select_maker_cd-button\"]/span[@class=\"ui-selectmenu-text\"]")
	WebElement wmakefirstvalue;
	
	@FindBy(xpath="(//div[@class=\"custom-select-item\"])[1]/select[@name=\"select_maker_cd\"]/option[@value=\"1010\"]")
	WebElement wmakeoption;
	
	@FindBy(xpath="//div[@id=\"slider-range-year\"]/div[@class=\"ui-slider-range ui-corner-all ui-widget-header\"]")                                     
	WebElement year;
	
	@FindBy(xpath="//div[@id=\"slider-range-price\"]/div[@class=\"ui-slider-range ui-corner-all ui-widget-header\"]")                                     
	WebElement price;
	
	
	@FindBy(xpath="//div[@id=\"slider-range-year\"]/span[@class=\"ui-slider-handle ui-corner-all ui-state-default\"][1]")                                     
	WebElement yearspanone;
	
	
	@FindBy(xpath="//div[@id=\"slider-range-year\"]/span[@class=\"ui-slider-handle ui-corner-all ui-state-default\"][2]")                                     
	WebElement yearspantwo;
	
	
	@FindBy(xpath="//div[@id=\"slider-range-price\"]/span[@class=\"ui-slider-handle ui-corner-all ui-state-default\"][1]")                                     
	WebElement pricespanone;
	
	
	@FindBy(xpath="//div[@id=\"slider-range-year\"]/span[@class=\"ui-slider-handle ui-corner-all ui-state-default\"][2]")                                     
	WebElement pricespantwo;
	
	
	
	
	
	@FindBy(xpath="//div[@id=\"ui-id-3\"]")
	WebElement wmakeoptionbyspan;
	
	
	
	@FindBy(xpath="//div[@id=\"slider-range-year\"]")                                     
	WebElement yeardivfirst;
	
	
    @FindBy(xpath="//input[@id=\"minyear\"]")                                     
	WebElement yeartext;
	
    @FindBy(xpath="//input[@id=\"minprice\"]")                                     
   	WebElement pricetext;
   	
    
    
    @FindBy(xpath="(//div[@class=\"custom-select-item\"])[1]")                                     
  	WebElement yearselectmaindivision;
    
 
    
    
    @FindBy(xpath="//span[@id=\"select_maker_cd-button\"]")                                     
  	WebElement makedge;
    
    
    
    @FindBy(xpath="//input[@type=\"submit\"]")                                     
  	WebElement button;
    
    
    @FindBy(xpath="(//span[@class=\"ui-selectmenu-text\"])[1]")                                     
   	WebElement spanunderdropdown;
    
    
    
    @FindBy(xpath="(//div[@class=\"custom-select-item\"])[1]")                                     
  	WebElement makedgedivison;
    
    
    
    
	
	public HomePage()
	{
		
		
	}
	
	public HomePage(WebDriver dfrombottom)
	{
		
		
		
     	d=dfrombottom;
		
     	 
	
		
		System.setProperty("webdriver.chrome.driver", "src/test/resources/chromedriver.exe");
		
		
		d.get("https://www.goo-net-exchange.com/");
		
		
		PageFactory.initElements( d, this); 
		
		
		d.manage().window().maximize();
		
		
		
		
		d.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		
		
		
	}
	
	
	public void clickonSearch()
	{
		
		button.click();
		
		
	}
	
	public void clickonPrice() throws InterruptedException
	{
	        
		
		    JavascriptExecutor js = (JavascriptExecutor) d;
        
	       // js.executeScript("arguments[0].setAttribute('style', 'left: 58.1395%; width: 41.8605%;')",yeardivfirst);
			
			js.executeScript("arguments[0].setAttribute('style', 'left: 1.00503%; width: 98.995%;')",price);
			
			//act.dragAndDropBy(year,(int) i, 0).perform();
			
		
			js.executeScript("arguments[0].setAttribute('style', 'left: 1.00503%;')",pricespanone);
			
			
			js.executeScript("arguments[0].setAttribute('style', 'left: 100%;')",pricespantwo);
			
			js.executeScript("arguments[0].setAttribute('style', 'left: 100%;')",pricespantwo);
			
			((JavascriptExecutor)d).executeScript("arguments[0].value=arguments[1]", pricetext, "¥150,000");
			
		
	
	}
	
	
	public String getthecarstext()
	{
	        
		
		return(noofcars.getText());
		
	
			
		
	
	}
	
	
	
	public void clickonMake() throws InterruptedException
	{
		
		
		
		
		
		
				
	
		
		
		//WebElement w= (WebElement) obj;
		
		
		
		//WebDriverWait waitother=new WebDriverWait(d,Duration.ofSeconds(10));
		
		//waitother.until(ExpectedConditions.elementToBeClickable(By.xpath("//select[@id=\"select_maker_cd\"]")));
		

        //JavascriptExecutor executor = (JavascriptExecutor) d;
		
	    //executor.executeScript("arguments[0].scrollIntoView(true);", findusersection);
	
		
		//executor = (JavascriptExecutor) d;
		
	    //executor.executeScript("arguments[0].scrollIntoView(true);", yearselectmaindivision);
	    
	    //executor = (JavascriptExecutor) d;
		
	    //executor.executeScript("arguments[0].scrollIntoView(true);", yeardivfirst);
		
	
		
		
		
		
		
		

		JavascriptExecutor executor = (JavascriptExecutor) d;
		
	    executor.executeScript("arguments[0].scrollIntoView(true);", makedge);
	    
	    
	    
	    
 
	    
	    
	    
	    
	    
	    
	    
	    
		
	   //WebDriverWait waitother=new WebDriverWait(d,Duration.ofSeconds(15));
		
	   // waitother.until(ExpectedConditions.elementToBeSelected(wmake));
	
		
		
		
		
	
	    

		//executor = (JavascriptExecutor)d; 
		
	  
	    
	  //  d.switchTo().activeElement();
	    
	    
	   // d.switchTo().
	    
	   
	   // makedge.click();
	    

	    		
	    	
	    
	
		//yeardivfirst.click();
		
		//String text="custom-select";
		
		
		//executor = (JavascriptExecutor)d; 
		//executor.executeScript("arguments[0].click();",wmake);
		
		//executor.ex("$j(\".custom-select-item div:contains('"+ text +"')\").click()");
		
		
	//	Actions s= new Actions(d);
		
		
//		s.sendKeys(wmake, Keys.chord(Keys.DOWN,Keys.DOWN,Keys.ENTER)).build().perform();
		    

        //executor = (JavascriptExecutor) d;
		
	    //executor.executeScript("\r\n"
	    //		+ "	    \"css = 'div#ui-menu-it-wrapper'+\r\n'"
	    //		+\"jQuery("' . $selector . '").click()");
		
	    WebDriverWait waitother=new WebDriverWait(d,Duration.ofSeconds(10));
	   
	   
	
	
		

		
        executor = (JavascriptExecutor) d;
		
	    executor.executeScript("arguments[0].scrollIntoView(true);",wmakeoption);
		
	    

	//	((JavascriptExecutor)d).executeScript(
			  //  "arguments[0].style.display = 'block';", yearselectmaindivision);
	    

		//((JavascriptExecutor)d).executeScript(
		 //  "arguments[0].style.display = 'inline';", wmake);
		

	
		
		
		
		
		
       // waitother=new WebDriverWait(d,Duration.ofSeconds(10));
		
    // 	waitother.until(ExpectedConditions.elementToBeClickable(wmakeoption));
		
		
	    executor.executeScript("arguments[0].scrollIntoView(true);",wmakefirstvalue);
		
	    waitother=new WebDriverWait(d,Duration.ofSeconds(10));
		
	//	waitother.until(ExpectedConditions.elementToBeClickable(wmakefirstvalue));
		
		
		
	//	executor.executeScript("arguments[0].click();", makedge);
		
		
//	    executor.executeScript("arguments[0].click();", makedgedivison);
		 
		 
		 
  //      executor.executeScript("arguments[0].click();", wmakeoption);
		 
		
    //    executor.executeScript("arguments[0].click();", wmake);
		 
		 
		 
		// System.out.println(wmakeoption.getText());
		 
		 
		 
		 Select obj=new Select(wmake);
		 
		    //Coordinates coordinate = ((Locatable) obj).getCoordinates();
		   // coordinate.onPage();
		   // coordinate.inViewPort();
			
			
	
		 
			
		
	//		executor.executeScript("arguments[0].click();", wmake);
			 
			
		
			
			executor = (JavascriptExecutor) d;
			
			executor.executeScript("window.scrollBy(0,-250)", "");
			
			//s.send_keys("LEXUS(9,970)").send_keys(Keys.ENTER).perform();
			
			
			
			//Thread.sleep(5000);
			
		
			   //System.out.println("The first element"+obj.getFirstSelectedOption());
			   
		
			     //  d.findElement(By.cssSelector("\\\\select[class='select_maker_cd']>option[value=\"1010\"]"));
			       
			   
			   d.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			   
			       
			       
			   String cssSelector ="select>option[value=\"1035\"]";
			   
			   
			   
			 JavascriptExecutor js = (JavascriptExecutor) d;
			   
		      StringBuilder stringBuilder = new StringBuilder();
		  stringBuilder.append("var x = $(\'"+cssSelector+"\');");
		        stringBuilder.append("x.click();");
		      js.executeScript(stringBuilder.toString());
			   
			   

			  // System.out.println("The first element"+obj.getFirstSelectedOption());
			   
			 List<WebElement> myElements = (obj.getOptions());
			 for(WebElement e : myElements) {
			   //System.out.println("The element"+e.getText());
			 }
			 
			 
			  // System.out.println("The option in the dropdown"+wmakeoption.getText());
			   
			   
			  // System.out.println("The option by xpath "+d.findElement(By.xpath("//option[@value=\"1010\"]")).getText());
			   
			   
			   
			   
			   
			   
			   
				
				//Actions s= new Actions(d);
				
				//s.sendKeys("LEXUS(9,970)", Keys.chord(Keys.DOWN,Keys.DOWN,Keys.ENTER)).build().perform();
			   
			
		//	d.switchTo().activeElement();
			
		 
	           //obj.selectByVisibleText("LEXUS(9,970)");
	           
	           
		 
		 
		 

		 //executor.executeScript("arguments[0].click();", wmakeoption);
		 
			   
			   
			   
			   
			   

				executor.executeScript ("document.getElementById(\"select_maker_cd\").style.display = \"block\";");
		 
				 executor.executeScript ("document.getElementById(\"select_maker_cd\").style.visibility = \"visible\";");
				 
				 
				 
				 
			/// executor.executeScript ("document.getElementById('wmake').click()");
			 
			 
			 //executor.executeScript ("document.getElementById(\"select_car_cd-button\").style.display = \"none\";");
			 

			 
			 
				d.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			 
				
				
			 //
				
			 
			// executor.executeScript ("document.getElementById(\"select_car_cd\").style.display = \"block\";");
			 
			 
		//	 executor.executeScript ("document.getElementById(\"select_car_cd\").style.visibility = \"visible\";");
			 
			 
			 
			 
			 
			 
			 
		//////	executor.executeScript("return document.getElementById('select_maker_cd-button').remove();");
		 
		 
		  //  obj.selectByIndex(2);
		 
		 
		 
	//	executor.executeScript("arguments[0].click();", wmakeoptionbyspan);
		
		
	//	 executor.executeScript("arguments[0].scrollIntoView(true);",obj.getFirstSelectedOption());
		 
		 
		
//wmakefirstvalue.sendKeys("TOYOTA(114,831)");
		 
		 
		//((JavascriptExecutor)d).executeScript(
	 // "arguments[0].style.display = 'none';", yearselectmaindivision);
		 
		 
		// System.out.println(wmakeoption.getText());
		 
		 
		 //executor.executeScript("arguments[0].click();",wmakeoption);
		 
		 
		
		// System.out.println(wmakeoptionbyspan.getText());
		 
		
	   // executor.executeScript("arguments[0].click();", wmakeoptionbyspan);
	    
	    
	    
	   // ((JavascriptExecutor)d).executeScript("arguments[0].value=arguments[1]", wmakefirstvalue.getText(), wmakeoptionbyspan.getText());
	    
        // wmakefirstvalue.sendKeys( wmakeoptionbyspan.getText());
	    
	    
	    
	    
	    
		
		//obj.selectByValue(null);
	    
	    
	    //obj.getFirstSelectedOption().sendKeys(wmakeoptionbyspan.getText());

	 obj.selectByIndex(2);
		
		
		//obj.selectByVisibleText("TOYOTA(114,831)");
		
	
		
	 executor.executeScript("return document.getElementById('select_maker_cd-button').remove();");
	 
	 
//	executor.executeScript("arguments[0].click();",wmakeoption);
		
		
		
		
		
		
		
		
    }
  
	
	public void dragyearSliderright()
	
	
	{
		
		
		
     //  Actions act=new Actions(d);
		
   
 

		
	
        
	//	while(i != 0)
		//{
		
		//Actions act=new Actions(d);
        JavascriptExecutor js = (JavascriptExecutor) d;
        
       // js.executeScript("arguments[0].setAttribute('style', 'left: 58.1395%; width: 41.8605%;')",yeardivfirst);
		
		js.executeScript("arguments[0].setAttribute('style', 'left: 58.1395%; width: 41.8605%;')",year);
		
		//act.dragAndDropBy(year,(int) i, 0).perform();
		
	
		js.executeScript("arguments[0].setAttribute('style', 'left: 58.1395%;')",yearspanone);
		
		
		js.executeScript("arguments[0].setAttribute('style', 'left: 100%;')",yearspantwo);
		
		js.executeScript("arguments[0].setAttribute('style', 'left: 100%;')",yearspantwo);
		
		((JavascriptExecutor)d).executeScript("arguments[0].value=arguments[1]", yeartext, "2005");
		
		//yeartext.sendKeys("2005");
		
		 
		
		/*
	     if(yeartext.getText().equals("2008"))
		{
			
			break;
			
		}
		*/
		
	//	i++;
		
		
		
		
        //}
	
		
	
	}
	
	public void clickonModel() throws InterruptedException
	{
		
		
		
		Select obj=new Select(d.findElement(By.id("select_car_cd")));
		
		
		

	   	JavascriptExecutor executor = (JavascriptExecutor) d;
		
		
		
		 //executor.executeScript ("document.getElementById(\"select_car_cd\").style.display = \"block\";");
		 
		 
	
		 
		 
	   
	  	
	  	
		 
		 //executor.executeScript ("document.getElementById('select_car_cd').click()");
		 
		 
		 
	executor.executeScript ("document.getElementById(\"select_car_cd\").style.display = \"block\";");
	
	
	
	 executor.executeScript ("document.getElementById(\"select_car_cd\").style.visibility = \"visible\";");
	 
	 
	 
	// executor.executeScript ("document.getElementById('select_car_cd').click()");
		 
	
	//executor.executeScript ("$('#select_maker_cd').val('1005');");
	
	
	
    Thread.sleep(2000);
    
    
	
  //	executor.executeScript ("$('#select_maker_cd').val('1010');");
  	
  	
  	
  	
    // Thread.sleep(40000);
     

  // 	executor.executeScript ("$('#select_maker_cd').val('1005');");
   	
   	
   	
   	
   	
		 
		 
	// executor.executeScript ("$('#select_car_cd').val('10051013');");
		 
		 
		 
    obj.selectByIndex(2);
    
		 
	    	//executor.executeScript("arguments[0].click();", makedge);
			
			
			//executor.executeScript("arguments[0].click();", makedgedivison);
				 
				 
				 
         //   executor.executeScript("arguments[0].click();", wmakeoption);
		 
		 
		 
		 
	executor.executeScript("return document.getElementById('select_car_cd-button').remove();");
		
		
		
	}
	
	
	
	

	
	
}
